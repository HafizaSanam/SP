Matrix =[[1, 2, 3, 4, 5, 6, 7, 8], 
	  [9, 22, 13, 54, 2, 3, 14, 3], 
	  [12, 4, 11, 35, 1, 6, 7, 7], 
	  [6, 23, 32, 44, 5, 2, 5, 3], 
	  [23, 22, 45, 52, 1, 6, 5, 6], 
	  [9, 56, 11, 43, 5, 1, 2, 6], 
	  [52, 51, 31, 26, 1, 5, 3, 3], 
	  [7, 33, 10, 27, 8, 77, 9, 65]]
print "Enter values for 2 by 2 matrix"

mat_00=input("Enter a Number for [0][0]: ")
mat_01=input("Enter a Number for [0][1]: ")
mat_10=input("Enter a Number for [1][0]: ")
mat_11=input("Enter a Number for [1][1]: ")

m_00=int(mat_00)
m_01=int(mat_01)
m_10=int(mat_10)
m_11=int(mat_11)

counter=0
for i in range(0,7):
	for j in range(0,7):
		if(Matrix[i][j] == m_00 and Matrix[i+1][j] == m_10 and Matrix[i][j+1] == m_01 and Matrix[i+1][j+1] == m_11):
			print "Matrix found at index ({0},{1})".format(i+1,j+1)
			counter=counter+1
			
		
if(counter is not 1):	
	print "Matrix does not exists"	


