import psutil
import datetime
import sys
import os


def process_info(pid):
   	
	list1=[]
	f=open('task1.py','r')
	process=psutil.Process(pid)
	parent = process.ppid()
	process1=psutil.Process(parent)

	ct = datetime.datetime.fromtimestamp(process.create_time())
    	print("createing_time {}".format(ct))
	p=psutil.Process()
	print p.open_files()
	print process.open_files()
	print process.memory_info()
	print process.as_dict(attrs=['pid'])
	print process.as_dict(attrs=['name'])			
	print process1.as_dict(attrs=['ppid'])
	print process1.as_dict(attrs=['name'])
	
	

def main():
	arguments = len(sys.argv)
	for arg in sys.argv[1:]:
		process_info(int(arg))	

if __name__ == "__main__":
	main()


	   
