import requests
import datetime
from bs4 import BeautifulSoup
import urllib
from PIL import Image
import os




def download_files(link,newPath):
	
	fw = open("LogFile.txt", "a")
	fw.write('\n' + repr(datetime.datetime.now()) + "      " + newPath)
	try:
        	if not os.path.exists(newPath):
        		os.makedirs(newPath)
        except OSError:
        	print ('Error: in Creating directory. ' + directory)
	
	
		
	
	if(link != ""):
		try:
			status = requests.get(link)
		        if(status.status_code == 200):
				parser_object = BeautifulSoup(status.content,"html.parser")
				div_tag_list = parser_object.find('pre')
				div_tag_list1 = div_tag_list.find_all('a')
				total_list =  len(div_tag_list1)
				
				if total_list >= 26:
					required_list = len(div_tag_list1) - 26
					count = 0
					for i in range(required_list , total_list):
						fw.write('\n' + repr(datetime.datetime.now()) + "    Start")
						count = count + 1
						div_element = div_tag_list1[i]
						div_tag_list1[i] = link + div_element['href']
						fw.write("Files " )
						r = requests.get(div_tag_list1[i])
						with open("/home/wajihabcsf15m537/Assignment-2/%s/file%d.mp3" %(newPath , count), 'wb') as f:  
						
    							f.write(r.content)
						fw.write('\n' + repr(datetime.datetime.now()) +    "     End")
						
					       
		except requests.ConnectionError:
			print("ERROR !")
		
		

def getCategories(URL):
	
    fw = open("LogFile.txt", "a")
    if(URL != ""):
        try:
            status = requests.get(URL)

            if(status.status_code == 200):
               parser_object = BeautifulSoup(status.content,"html.parser")
               
               div_tag_list = parser_object.find('pre')
	       div_tag_list1 = div_tag_list.find_all('a')
	       count = len(div_tag_list1)
	       count1 = 0
	       fw.write(repr(datetime.datetime.now()) + "   Total Qari: " + repr(count) + '\n')
	       fw.write("Starting Process   ")

               for a in div_tag_list1:
			count1 = count1 + 1
			fw.write(repr(datetime.datetime.now()) + "   " + repr(count1) + "   Out of  " + repr(count))
			link1 = URL + (a['href'])
			link2 = (a['href'])
			if link1 != "https://download.quranicaudio.com/" :
                   		download_files(link1,link2)
	       fw.close()


        except requests.ConnectionError:
            print("ERROR !")
        
	

	
#___________________________#
def main():
    URL = "https://download.quranicaudio.com/quran/"

    getCategories(URL)


#___________________________#
if __name__ == "__main__":
    main()

