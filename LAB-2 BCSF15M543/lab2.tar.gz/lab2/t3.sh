#!/bin/bash

echo "FileName: File type: owner"
for filename in `ls`
do

if [ "$filename" == "*.txt" ]
then
	if [ $? = 0 ]
	then
	echo fid
	fi
fi

done
