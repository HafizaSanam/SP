#!/bin/bash

showAllOwners(){

arr=(`ls ~`)
count=${#arr[*]}
for i in `seq 1 $count`
do
	arr1=(`ls -l ${arr[i]}`)
	echo ${arr1[2]} ${arr1[8]}

done
}
showAllOwners $1
