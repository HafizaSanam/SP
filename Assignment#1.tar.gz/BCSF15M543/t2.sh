#!/bin/bash
inputfile=$1
counter=0
if [ $# -eq 0 ]
then
	echo "You don't entered file name. Please enter a file name"
	exit 0

elif [ $# -gt 1 ]
then
	echo "You Entered too many arguments..."
	exit 0
fi
#if entered argument is not a file
if [ ! -f $inputfile ]
then
	echo "$inputfile not a file"
	exit 0
fi
 
while read line
do
	#counter variable to check line is even or odd
	((counter++))
	EvenNo=$(( counter%2 ))

	if [ $EvenNo -eq 0 ] 
	then
		#if line is even then that line is Append into file named evenfile
		echo $line >> evenfile 
	else
		#if line is odd then that line is Append into file named oddfile
		echo $line >> oddfile
	fi

done < $inputfile #read input line by line from file named inputfile
