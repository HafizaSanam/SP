#!/bin/bash

#check count of command line args
if [ $# = 1 ]
then
	#$1 contains file name
	file1=$1

	#sort command sort file pass output to pipe that is input of uniq command
	#after sorting uniq command merge identical lines and -u removes those identical line
	sort $file1 | uniq -u

elif [ $# -gt 1 ]
then
	echo "you entered too many arguments..."
else

	echo "Please enter Command Line Argument..."

fi
