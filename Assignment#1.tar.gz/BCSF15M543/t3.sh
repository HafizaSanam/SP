#!/bin/bash
#save passwd file
declare -r passwdfile=/etc/passwd


function Is_lower() 
{

    #$@ contains strings
    str=$@
    #convert all Uppercase letters into lower case
    echo $(tr '[:upper:]' '[:lower:]'<<<"${str}")
}

function Is_root() 
{
   #root id is 0 so check id if id=0 then return true otherwise return false
   [ $(id -u) -eq 0 ] && return 0 || return 1
}


function Is_user_exits() 
{
    #$1 contains username
    u="$1"
    #find username from passwd file if found then returns true(0) else return false(1)
    grep -q "^${u}" $passwdfile && return 0 || return 1
}

#calling Is_root function 

Is_root && echo "You are logged in as root." || echo "You are not logged in as root."

#calling Is_user_exists function with argument username 

Is_user_exits "sanam" && echo "User Exists." || echo "User Not Exists."

#var1 contains text that converted into lower case
var1="THIS tExt Is CONVERTED INTO LowerCase..."

#calling Is_lower function with arg var1
echo -e "$(Is_lower ${var1})"


