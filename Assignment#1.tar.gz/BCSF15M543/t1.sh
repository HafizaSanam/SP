#!/bin/bash

for file in `ls`
do

	#  extracing the extension of the file in your present working directory 
	ext=${file##*.}
	
	#check if a directory exists by this name already ?
	
	# checks if the argument is a directory or not ?
	if [ -d $ext ] 
	then
		
		# if directory already exists. move all the same extension files in it
		mv $file $ext
	else
		#directory doesnt exists. Thus first create a directory. then  move files in it
	
		mkdir $ext
		mv $file $ext
	
	fi

done
