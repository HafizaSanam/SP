#include<stdio.h>

#include "mtStr.h"
void main(){

	char arr[4]={'a' , 'a' , 'b' , 'a'};
	int result = isPalindrome(arr,4);
	if(result == 1)
		printf("Yes Palindrome\n");

	else
		printf("Not Palindrome\n");

}
