int isPalindrome(char *arr , int size){

	int length = size-1;
	int i = 0 , flag;
	while(length > 0)
	{
		if(arr[i] == arr[length])
			flag = 1;
		else{
			flag = -1;
			break;
		}
		length--;
		i++;
	}
	
	return flag;

}
