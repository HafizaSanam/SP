#include<stdio.h>
#include "mtStr.h"
#include "myMath.h"

void main(){

	int a = 4 , b = 3;
	int result = isEqual(a,b);
	if(result == 1)
		printf("Numbers are Equal\n");

	else
		printf("Numbers are not Equal\n");
	
	swap(a,b);

	char arr[4]={'a' , 'b' , 'b' , 'a'};
	int result1 = isPalindrome(arr,4);
	if(result1 == 1)
		printf("Yes Palindrome\n");

	else
		printf("Not Palindrome\n");

}
