#include<stdio.h>


void main(){

	int a = 4 , b = 3;
	int result = isEqual(a,b);
	if(result == 1)
		printf("Numbers are Equal\n");

	else
		printf("Numbers are not Equal\n");
	
	swap(a,b);

	
}
