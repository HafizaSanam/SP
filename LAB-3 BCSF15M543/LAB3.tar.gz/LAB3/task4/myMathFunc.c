int isEqual(int a , int b)
{
	if(a==b)
	    return 1;
	else
	    return -1;
}
void swap(int a , int b)
{
	printf("Before Swapping  \n");
	printf("Value of a = %d \n" , a);
	printf("Value of b = %d \n" , b);
	a = a + b;
	b = a - b;
	a = a - b;
	printf("After Swapping  \n");
	printf("Value of a = %d \n" , a);
	printf("Value of b = %d \n" , b);
	printf("Edited  \n");
}
