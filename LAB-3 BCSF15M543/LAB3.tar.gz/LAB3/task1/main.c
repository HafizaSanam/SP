#include<stdio.h>
//#include<stdlib.h>
#include "myMath.h"
void main(){

	int a = 3 , b = 3;
	int result = isEqual(a,b);
	if(result == 1)
		printf("Numbers are Equal\n");

	else
		printf("Numbers are not Equal\n");
	
	swap(a,b);

}
